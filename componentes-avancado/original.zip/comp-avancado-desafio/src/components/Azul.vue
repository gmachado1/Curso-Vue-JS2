<template>
    <div class="caixa azul">
        Conteúdo do Componente Azul
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>
