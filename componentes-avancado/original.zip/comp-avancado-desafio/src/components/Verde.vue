<template>
    <div class="caixa verde">
        Conteúdo do Componente Verde
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>
