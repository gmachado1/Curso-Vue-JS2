<template>
    <div class="caixa vermelho">
        Conteúdo do Componente Vermelho
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
